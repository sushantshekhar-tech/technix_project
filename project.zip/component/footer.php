<div class="container">
        <div class="row">
            <div class="col-md-6">
                <p>&copy; 2024 Technix. All rights reserved.</p>
            </div>
            <div class="col-md-6">
                <ul class="list-inline">
                    <li class="list-inline-item"><a href="#">Privacy Policy</a></li>
                    <li class="list-inline-item"><a href="#">Terms of Service</a></li>
                    <li class="list-inline-item"><a href="jobs.php">Careers</a></li>
                    <li class="list-inline-item"><a href="admin">Admin</a></li>
                </ul>
            </div>
        </div>
    </div>